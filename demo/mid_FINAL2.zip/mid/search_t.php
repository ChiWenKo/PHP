<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>查詢課程</title>
	<style>
		.large-title {
		font-size: 25px;
		}
	</style>
</head>
<body>
	<a href = "teacher.php"><button>返回</button></a><p>
	<h1 class="large-title">查詢課程</h1>
	<!-- <a href = "add.php"><button>加選</button></a>
    <a href = "drop.php"><button>退選</button></a>
    <a href = "focus.php"><button>關注</button></a><p> -->
	<!-- <a href="student.php"><button>查看課表</button></a><p> -->
    <!-- <a href = "logout.php"><button>登出</button></a><p>	 -->

	<form name="search" method="post" action="search_t_1.php">
	課程代號: <input name ="inquire_id">
    <br>課程名稱: <input name ="inquire_name">
	<br>開課系所: <input name ="inquire_department">
	<br>課程開始時間: <input name ="inquire_time"><br><br>

	<input type="submit" name="search" value="查詢">
	
	
	
	</form>
	
	<?php
	
		session_start();

		$dbhost = '127.0.0.1';
		$dbuser = 'hj';
		$dbpass = 'test1234';
		$dbname = 'testdb';
		$conn = mysqli_connect($dbhost, $dbuser, $dbpass) or die('Error with MySQL connection');
		mysqli_query($conn, "SET NAMES 'utf8'");
		mysqli_select_db($conn, $dbname);
	
	?>
</body>
</html>





