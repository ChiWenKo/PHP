<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>save error</title>
</head>
<body>

<p>上傳失敗</p>
<a href = "t1_teacher_info.php"><button>返回</button></a><p>

</body>
</html>