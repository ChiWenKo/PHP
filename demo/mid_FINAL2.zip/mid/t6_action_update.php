<?php
    //$flag = 1;
    // 上傳
	if(isset($_POST['update'])) {
        session_start();
        $enter_c_id=$_SESSION["enter_c_id"];
		$teacher_id=$_SESSION["teacher_id"] ;

        $info = $_SESSION["info"];
        $attendclass = $_SESSION["attendclass"];
        $score = $_SESSION["score"];
        $book = $_SESSION["book"];

        $dbhost = '127.0.0.1';
        $dbuser = 'hj';
        $dbpass = 'test1234';
        $dbname = 'testdb';
        $conn = mysqli_connect($dbhost, $dbuser, $dbpass) or die('Error with MySQL connection');
        mysqli_query($conn, "SET NAMES 'utf8'");
        mysqli_select_db($conn, $dbname);

        $sql1 = "UPDATE enrollments_teacher
                SET c_info = '.$info.', c_attendclass = '.$attendclass.', c_score = '.$score.', c_book = '.$book.'
			    WHERE t_id = '.$teacher_id.' AND c_id = '.$enter_c_id.';";
	    $result = mysqli_query($conn, $sql1) or die('MySQL query error');
    }
    header("Location: t0_update.php");
	exit;   
?>