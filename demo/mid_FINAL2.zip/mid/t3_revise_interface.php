<!DOCTYPE html>
<?php
//顯示
//接收資料
		session_start();
		//$MyHead=$_POST["courses_id"];
		$enter_c_id=$_SESSION["enter_c_id"];
		$teacher_id=$_SESSION["teacher_id"] ;
		$teacher_id=$_SESSION["teacher_id"] ;
		$teacher = $_SESSION['t_name'];
		$course_id = $_SESSION['c_id'];
		$course = $_SESSION['c_name'];
		$required = $_SESSION['required'];
		$day = $_SESSION['day'];
		$start = $_SESSION['start_time'];
		$end = $_SESSION['end_time'];
?>
<script>
	function myFunction(){
        
		var r=confirm("修改進度尚未儲存，請問確定離開頁面嗎？");
		if (r == true){
			document.location.href="http://localhost/mid/t0_error_save.php";
		}
	}
</script>

<html lang="en">
	<head>
		<meta charset="UTF-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>修改課程大綱</title>
		<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
		<style>
			
	header {
		background-color: #017592;
		padding: 30px;
		text-align: center;
		font-size: 35px;
		color: white;
	}

	section::after {
		content: "";
		display: table;
		clear: both;
	}

		</style>
	</head>

	<body>
		<div class="container">
			<header>
				<?php 
					echo "<h1 style='font-size:28px; text-align: center;'>" .$course. "   " .$required."</h1>";
				?>
			</header>
			<section class="mt-3 mb-3">
				<div class="container">
					<div class="tab-content mt-3">
						<div id="introduction" class="tab-pane fade mb-4 show active">
						<form action="t4_action_save.php" method="post">
							<h2>課程描述</h2>
							<hr>
							<p><textarea name="info" rows="10" cols="150"></textarea></p>
							
							<h2>上課資訊</h2>
							<hr>
							<?php
								echo "<p>授課老師：" .$teacher. "</p>";
								echo "<p>課程代碼：" .$course_id. "</p>";
								echo "<p>上課時間：" .$day. ", " .$start. "-" .$end. "</p>"
							?>
							<p><textarea name="attendclass" rows="10" cols="150"></textarea></p>

							<h2>評分規則</h2>
							<hr>
							<p><textarea name="score" rows="10" cols="150"></textarea></p>

							<h2>上課用書</h2>
							<hr>
							<p><textarea name="book" rows="10" cols="150"></textarea></p>

							<p><input type="submit" name="submit" value="儲存">   <input type="button" value="離開" onclick="myFunction()"></p>
						</form>
	
					</div>
				</div>
			</section>	
		</div>
	</body>
</html>

		