<!DOCTYPE html>
<?php
//預覽
//接收資料
		session_start();
		//$MyHead=$_POST["courses_id"];
		$teacher = $_SESSION['t_name'];
		$course_id = $_SESSION['c_id'];
		$course = $_SESSION['c_name'];
		$required = $_SESSION['required'];
		$day = $_SESSION['day'];
		$start = $_SESSION['start_time'];
		$end = $_SESSION['end_time'];

        $info = $_SESSION['info'];
        $attendclass = $_SESSION['attendclass'];
        $score = $_SESSION['score'];
        $book = $_SESSION['book'];
?>

<script>
	function myFunction(){
		var r=confirm("資訊尚未上傳，請問確定離開頁面嗎？");
		if (r == true){
			document.location.href="http://localhost/mid/t0_error_save.php";
		}
	}
</script>

<html lang="en">
	<head>
		<meta charset="UTF-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>預覽</title>
		<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
		<style>
			
	header {
		background-color: #017592;
		padding: 30px;
		text-align: center;
		font-size: 35px;
		color: white;
	}

	section::after {
		content: "";
		display: table;
		clear: both;
	}

		</style>
	</head>

	<body>
		<div class="container">
			<header>
				<?php 
					echo "<h1 style='font-size:28px; text-align: center;'>" .$course. "   " .$required."</h1>";
				?>
			</header>
			<section class="mt-3 mb-3">
				<div class="container">
					<div class="tab-content mt-3">
						<div id="introduction" class="tab-pane fade mb-4 show active">
							<h2>課程描述</h2>
							<hr>
							<?php
                                echo "<p>" .$info. "</p>";
                            ?>
							
							<h2>上課資訊</h2>
							<hr>
							<?php
								echo "<p>授課老師：" .$teacher. "</p>";
								echo "<p>課程代碼：" .$course_id. "</p>";
								echo "<p>上課時間：" .$day. ", " .$start. "-" .$end. "</p>";
                                echo "<p>" .$attendclass. "</p>";
							?>

							<h2>評分規則</h2>
							<hr>
							<?php
                                echo "<p>" .$score. "</p>";
                            ?>

							<h2>上課用書</h2>
							<hr>
							<?php
                                echo "<p>" .$book. "</p>";
                            ?>


                            <form action="t0_update.php" method="post">
								<p><input type="submit" name="update" value="上傳">   <input type="button" value="離開" onclick="myFunction()"></p>
						    </form>
							
							
					</div>
				</div>
			</section>	
		</div>
	</body>
</html>

		