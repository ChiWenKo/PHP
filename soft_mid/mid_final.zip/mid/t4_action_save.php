<?php
    //$flag = 1;
    // 存取修改完成的表單內容
	if(isset($_POST['submit'])) {
        session_start();
        $enter_c_id=$_SESSION["enter_c_id"];
		$teacher_id=$_SESSION["teacher_id"] ;

        $info = $_POST["info"];
        $attendclass = $_POST["attendclass"];
        $score = $_POST["score"];
        $book = $_POST["book"];


        $dbhost = '127.0.0.1';
        $dbuser = 'hj';
        $dbpass = 'test1234';
        $dbname = 'testdb';
        $conn = mysqli_connect($dbhost, $dbuser, $dbpass) or die('Error with MySQL connection');
        mysqli_query($conn, "SET NAMES 'utf8'");
        mysqli_select_db($conn, $dbname);

        $sql = "SELECT c_id, c_name, required, day, start_time, end_time, t.t_name
				FROM enrollments_teacher e 
				LEFT JOIN teacher t ON t.t_id = e.t_id
				WHERE t.t_id=".$teacher_id. " AND e.c_id=".$enter_c_id.";";
		$result = mysqli_query($conn, $sql) or die('MySQL query error');

		while($row = mysqli_fetch_array($result)){
			$_SESSION['t_name'] = $row['t_name'];
			$_SESSION['c_id'] = $row['c_id'];
			$_SESSION['c_name'] = $row['c_name'];
			$_SESSION['required'] = $row['required'];
			$_SESSION['day'] = $row['day'];
			$_SESSION['start_time'] = $row['start_time'];
			$_SESSION['end_time'] = $row['end_time'];
		}
        $_SESSION['info'] = $info;
        $_SESSION['attendclass'] = $attendclass;
        $_SESSION['score'] = $score;
        $_SESSION['book'] = $book;
		

		header("Location: t5_preview.php");
		exit;   
    }
    /*
    if(isset($_POST['leave'])){
        //header('Location: error_save.php?status=savefail');
        //exit();
        echo "確定要離開嗎?"
        echo "<button onclick='myFunction()'>確定要離開嗎?</button>"

    }*/
    
        
?>
