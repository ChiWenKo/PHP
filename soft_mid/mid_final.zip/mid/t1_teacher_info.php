<a href = "logout.php"><button>登出</button></a><p>

<?php
//老師個人資訊
		session_start(); //開始存取
		$teacher_id=$_SESSION["teacher_id"] ;
	
		$dbhost = '127.0.0.1';
		$dbuser = 'hj';
		$dbpass = 'test1234';
		$dbname = 'testdb';
		$conn = mysqli_connect($dbhost, $dbuser, $dbpass) or die('Error with MySQL connection');
		mysqli_query($conn, "SET NAMES 'utf8'");
		mysqli_select_db($conn, $dbname);
		$sql = "SELECT distinct t_id, t_name
				FROM teacher 
				where t_id =".$teacher_id.";";
		$result = mysqli_query($conn, $sql) or die('MySQL query error');
		
		while($row = mysqli_fetch_array($result)){
			echo "<br>您好，" .$row['t_name']. "<br>";
			echo "<br>以下是您本學期的課表:<br>";
		}

		//echo" <form method='post' action='action2_teacher.php'>請輸入想修改的課程: <input name ='enter_c_id'><input type='submit' value='修改課程大綱'></form>";

		//顯示已選列表
		$sql = "SELECT distinct  c_id, c_name, required, day, start_time, end_time 
				FROM enrollments_teacher 
				where t_id =".$teacher_id. ";";
		$result = mysqli_query($conn, $sql) or die('MySQL query error');
		
		//echo "<br>",$teacher_id." 's 的課表<br>";	
		echo "<table border='1'><br>";
		echo "<tr> 
				<th>   </th> 
				<th> 選課代號 </th> 
				<th> 課程名稱 </th>
				<th> 必選修 </th>
				<th> 上課日 </th> 
				<th> 上課 </th> 
				<th> 下課 </th>
			<tr>";
		
		//echo "<form method='post' action='action2_teacher.php'>";
		while($row = mysqli_fetch_array($result)){
			echo "<tr>";
			//echo "<td><input type='submit' name = .$row['c_id']. value='修改課程大綱'></td>";
			
			echo "<td>";
			echo "<form method='post' action='t2_action_revise.php'>";
			echo "<input type='hidden' name ='enter_c_id' value=".$row['c_id'].">";
			echo "<input type='submit' value=' 修改課程大綱 '>";
			echo "</form>";
			echo "</td>";

			echo "<td>" .$row['c_id']."</td>";
			echo "<td>" .$row['c_name']."</td>";
			echo "<td>" .$row['required']."</td>";
			echo "<td>" .$row['day']."</td>";
			echo "<td>" .$row['start_time']."</td>";
			echo "<td>" .$row['end_time']."</td>";
			echo "<tr>";
		}
		//echo "</form>";
		echo "</table>";
?>
