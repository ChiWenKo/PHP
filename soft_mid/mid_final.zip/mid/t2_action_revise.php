<?php
	//修改課程判斷
	session_start();

	$enter_c_id=$_POST["enter_c_id"];
	$teacher_id=$_SESSION["teacher_id"] ;

	$dbhost = '127.0.0.1';
	$dbuser = 'hj';
	$dbpass = 'test1234';
	$dbname = 'testdb';
	$conn = mysqli_connect($dbhost, $dbuser, $dbpass) or die('Error with MySQL connection');
	mysqli_query($conn, "SET NAMES 'utf8'");
	mysqli_select_db($conn, $dbname);

	/*
	$sql = "SELECT distinct  c_id, c_name, required, day, start_time, end_time 
			FROM enrollments_teacher
			where t_id ='.$teacher_id.' AND c.c_id='$enter_c_id';";
	$result = mysqli_query($conn, $sql) or die('MySQL query error');
	*/

	$sql = "SELECT c_id, c_name, required, day, start_time, end_time, t.t_name
			FROM enrollments_teacher e 
			LEFT JOIN teacher t ON t.t_id = e.t_id
			WHERE t.t_id=".$teacher_id. " AND e.c_id=".$enter_c_id.";";
	$result = mysqli_query($conn, $sql) or die('MySQL query error');

	while($row = mysqli_fetch_array($result)){
		$_SESSION['t_name'] = $row['t_name'];
		$_SESSION['c_id'] = $row['c_id'];
		$_SESSION['c_name'] = $row['c_name'];
		$_SESSION['required'] = $row['required'];
		$_SESSION['day'] = $row['day'];
		$_SESSION['start_time'] = $row['start_time'];
		$_SESSION['end_time'] = $row['end_time'];
	}
	$_SESSION['enter_c_id'] = $enter_c_id;
	
	header("Location: t3_revise_interface.php");
	exit;

?>

