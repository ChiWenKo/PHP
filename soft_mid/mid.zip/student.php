<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>選課系統</title>
	<style>
		.large-title {
		font-size: 25px;
		}
	</style>
</head>
<body>
	<h1 class="large-title">身分:學生</h1>
    <a href = "search.php"><button>課程查詢</button></a>
    <a href = "add.php"><button>加選</button></a>
    <a href = "drop.php"><button>退選</button></a>
    <a href = "focus.php"><button>關注</button></a><p>
    <a href = "logout.php"><button>登出</button></a><p>	
	</form>
	
<?php
	
	session_start(); //開始存取
	$student_id=$_SESSION["student_id"] ;
	
	$dbhost = '127.0.0.1';
	$dbuser = 'hj';
	$dbpass = 'test1234';
	$dbname = 'testdb';
	$conn = mysqli_connect($dbhost, $dbuser, $dbpass) or die('Error with MySQL connection');
	mysqli_query($conn, "SET NAMES 'utf8'");
	mysqli_select_db($conn, $dbname);
	
	//學生個人資訊
	$sql = "SELECT distinct s_id, s_name,major,credits,s_grade
			FROM student 
			where s_id =".$student_id.";";
	$result = mysqli_query($conn, $sql) or die('MySQL query error');
	echo "個人資訊";	
	echo "<br><table border='1'><br>";
	echo "<tr> 
			<th> 學號 </th> 
			<th> 姓名 </th>
			<th> 科系 </th>
			<th> 年級 </th> 
			<th> 已選學分 </th> 
			<tr>";
	while($row = mysqli_fetch_array($result)){
		echo "<tr>";
		echo "<td>" .$row['s_id']."</td>";
		echo "<td>" .$row['s_name']."</td>";
		echo "<td>" .$row['major']."</td>";			
		echo "<td>" .$row['s_grade']."</td>";			
		echo "<td>" .$row['credits']."</td>";
		echo "<tr>";		
	}
	echo "</table>";

	//查詢已選課表
	echo "<div style='display: flex;'>";
    echo "<div style='flex: 1; margin-right: 10px;'>";
	//學生姓名
	$sql_n = "SELECT s_name FROM student WHERE s_id =".$student_id.";";
	$result_n = mysqli_query($conn, $sql_n) or die('MySQL query error');
	while($row_n = mysqli_fetch_array($result_n)){
		echo "<br>".$row_n["s_name"]. " 的已選課表<br>";	
	}
	//已選課表
	$sql2 = "SELECT distinct  c_id, c_name, required, c_credit, day, start_time,end_time 
			 FROM enrollments 
			 where s_id =".$student_id.";";
	$result2 = mysqli_query($conn, $sql2) or die('MySQL query error');	

	echo "<table border='1'><br>";
	echo "<tr> 
			<th> 選課代號 </th> 
			<th> 課程名稱 </th>
			<th> 必選修 </th>
			<th> 學分數 </th> 
			<th> 上課日 </th> 
			<th> 上課 </th> 
			<th> 下課 </th>
			<tr>";
	while($row2 = mysqli_fetch_array($result2)){
		echo "<tr>";
		echo "<td>" .$row2['c_id']."</td>";
		echo "<td>" .$row2['c_name']."</td>";
		echo "<td>" .$row2['required']."</td>";
		echo "<td>" .$row2['c_credit']."</td>";
		echo "<td>" .$row2['day']."</td>";
		echo "<td>" .$row2['start_time']."</td>";
		echo "<td>" .$row2['end_time']."</td>";
		echo "<tr>";
	}
	echo "</table>";
	echo "</div>";
    echo "<div style='flex: 1;'>";

	//學生姓名
	$sql_n = "SELECT s_name FROM student WHERE s_id =".$student_id.";";
	$result_n = mysqli_query($conn, $sql_n) or die('MySQL query error');
	while($row_n = mysqli_fetch_array($result_n)){
		echo "<br>".$row_n["s_name"]. " 的功課表<br>";	
	}
	//功課表
	$sql2 = "SELECT distinct  c_id, day, start_time,end_time FROM enrollments where s_id =".$student_id.";";
	$result2 = mysqli_query($conn, $sql2) or die('MySQL query error');	
	$takes = array(array(), array(), array(), array(), array());
	for ($i = 0; $i < 10; $i++) {
		for ($j = 0; $j < 5; $j++) {
			$takes[$j][$i] = 0;
		}
	}
	
	while($row2 = mysqli_fetch_array($result2)){
		$start = intval(substr($row2['start_time'], 0, 2));
		$end = intval(substr($row2['end_time'], 0, 2));
		$dayIndex = -1;
		// 判斷星期幾，並將索引指派到 $dayIndex 中
		switch ($row2['day']) {
			case "星期一":
				$dayIndex = 0;
				break;
			case "星期二":
				$dayIndex = 1;
				break;
			case "星期三":
				$dayIndex = 2;
				break;
			case "星期四":
				$dayIndex = 3;
				break;
			case "星期五":
				$dayIndex = 4;
				break;
			default:
				break;
		}
		// 將課程 ID 放入對應的時間表中
		if ($dayIndex >= 0 && $start >= 8 && $end <= 18) {
			for ($i = $start - 8; $i < $end - 8; $i++) {
				$takes[$dayIndex][$i] = intval($row2['c_id']);
				
			}
		}
	}
	
	//關注加入課表
	$focusForm = array(array(), array(), array(), array(), array());
	for ($i = 0; $i < 10; $i++) {
		for ($j = 0; $j < 5; $j++) {
			for($t = 0;$t < 5;$t++) {
				$focusForm[$j+$i*10][$t] = 0;
			}
		}
	}
	
	$sql2 = "SELECT * FROM focus 
			 where s_id =".$student_id.";";
	$result2 = mysqli_query($conn, $sql2) or die('MySQL query error');
	while($row2 = mysqli_fetch_array($result2)){
		$start = intval(substr($row2['start_time'], 0, 2));
		$end = intval(substr($row2['end_time'], 0, 2));
		$dayIndex = -1;
		// 判斷星期幾，並將索引指派到 $dayIndex 中
		switch ($row2['day']) {
			case "星期一":
				$dayIndex = 0;
				break;
			case "星期二":
				$dayIndex = 1;
				break;
			case "星期三":
				$dayIndex = 2;
				break;
			case "星期四":
				$dayIndex = 3;
				break;
			case "星期五":
				$dayIndex = 4;
				break;
			default:
				break;
		}
		// 將課程 ID 放入對應的時間表中
		if ($dayIndex >= 0 && $start >= 8 && $end <= 18) {
			$focus_count = 0;
			for ($i = $start - 8; $i < $end - 8; $i++) {
				while($focusForm[$dayIndex+$i*10][$focus_count] != 0)	$focus_count++;
				$focusForm[$dayIndex+$i*10][$focus_count] = intval($row2['c_id']);
			}
		}
	}
	
	echo "<table border='1'><br>";
	echo "<tr> 
			<th> 節次 </th> 
			<th> 一 </th> 
			<th> 二 </th> 
			<th> 三 </th>
			<th> 四 </th>
			<th> 五 </th>
			<tr>";
	for ($i = 0; $i < 10; $i++) {
		echo "<tr>";
		echo "<th>" . ($i + 1) . "</th>";
		for ($j = 0; $j < 5; $j++) {
			$course_times = 0;
			if ($takes[$j][$i] != 0 && $focusForm[$j+$i*10][0] != 0) {
				echo "<td style='background-color: #e46451;'>"; // 更改背景色
				echo $takes[$j][$i]; // 顯示課程代號或其他相關資訊
				for($t = 0;$t < 5;$t++) {
					if($focusForm[$j+$i*10][0] == 0)	echo "</td>";
					else {
						if($focusForm[$j+$i*10][$t] != 0)	echo "<br>".($focusForm[$j+$i*10][$t])."</td>";
						else	echo "</td>";					
					}
				}
			}
			else {
				// 其他單一課程的顯示
				if ($takes[$j][$i] != 0) {
					echo "<td style='background-color: #9ccd81;'>".$takes[$j][$i];
				} 
				else if ($focusForm[$j+$i*10][0] != 0) {
					for($t = 0;$t < 5;$t++) {
						if($t == 0)	echo "<td style='background-color: #64c2c2;'>".$focusForm[$j+$i*10][0]; // 可能的其他課程顯示
						else if($focusForm[$j+$i*10][$t] != 0)	echo "<br>".($focusForm[$j+$i*10][$t]);
					}
				} 
				else {
					echo "<td>	"; // 若無課程，顯示空格
				}
				echo "</td>";
			}
		}
		echo "</tr>";
	}
	echo "</table>";
	echo "</div>";
	echo "</div>";

	//關注清單
	//學生姓名
	
		echo "<br>關注清單<br>";
		
		if (isset($_GET['status'])) {
			if($_GET['status'] === 'successful'){
				echo '<span style="color:red"><p>取消關注成功</p></span>';
			}
		}

	//關注清單
	$sql2 = "SELECT * FROM focus 
			 where s_id =".$student_id.";";
	$result2 = mysqli_query($conn, $sql2) or die('MySQL query error');	
	echo "<table border='1'><br>";
		echo "<tr>
                <th>         </th>
				<th> 選課代號 </th> 
				<th> 課程名稱 </th>
				<th> 必選修 </th> 
				<th> 學分數 </th>
				<th> 開課系所 </th> 
				<th> 開課年級 </th>
				<th> 人數上限 </th> 
				<th> 已選人數 </th>
				<th> 上課日 </th> 
				<th> 上課 </th>
				<th> 下課 </th>
			<tr>";

	while($row2 = mysqli_fetch_array($result2)){
		echo "<tr>";
            echo "<td>","<form action='focus_3.php' method='post'>";
            echo "<input type='hidden' name='drop_c_id' value=".$row2['c_id'].">";
            echo "<input type='submit' value='取消'></form>";
            echo "</td>" ;
		echo "<td>" .$row2['c_id']."</td>";
		echo "<td>" .$row2['c_name']."</td>";
		echo "<td>" .$row2['required']."</td>";
		echo "<td>" .$row2['c_credit']."</td>";
		echo "<td>" .$row2['department']."</td>";
		echo "<td>" .$row2['c_grade']."</td>";
		echo "<td>" .$row2['c_limit']."</td>";
		echo "<td>" .$row2['current_enrollment']."</td>";
		echo "<td>" .$row2['day']."</td>";
		echo "<td>" .$row2['start_time']."</td>";
		echo "<td>" .$row2['end_time']."</td>";
		echo "<tr>";
	}
	echo "</table>";
?>






