-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- 主機： 127.0.0.1
-- 產生時間： 2023-11-28 09:40:26
-- 伺服器版本： 10.4.28-MariaDB
-- PHP 版本： 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 資料庫： `testdb`
--

-- --------------------------------------------------------

--
-- 資料表結構 `assistant`
--

CREATE TABLE `assistant` (
  `a_id` int(11) NOT NULL,
  `a_name` varchar(255) NOT NULL,
  `a_password` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 傾印資料表的資料 `assistant`
--

INSERT INTO `assistant` (`a_id`, `a_name`, `a_password`) VALUES
(6548, '助教A', 123),
(9412, '助教B', 452);

-- --------------------------------------------------------

--
-- 資料表結構 `classtime`
--

CREATE TABLE `classtime` (
  `start_time` varchar(100) NOT NULL,
  `end_time` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 傾印資料表的資料 `classtime`
--

INSERT INTO `classtime` (`start_time`, `end_time`) VALUES
('08:10', '10:00'),
('08:10', '11:00'),
('08:10', '12:00'),
('09:10', '11:00'),
('09:10', '12:00'),
('10:10', '12:00'),
('13:10', '15:00'),
('13:10', '16:00'),
('13:10', '17:00'),
('14:10', '16:00'),
('14:10', '17:00'),
('15:10', '17:00');

-- --------------------------------------------------------

--
-- 資料表結構 `courses`
--

CREATE TABLE `courses` (
  `c_id` int(11) NOT NULL,
  `c_name` varchar(100) NOT NULL,
  `required` varchar(100) NOT NULL,
  `c_credit` int(11) NOT NULL,
  `department` varchar(100) NOT NULL,
  `c_grade` int(11) NOT NULL,
  `c_limit` int(11) NOT NULL,
  `current_enrollment` int(11) NOT NULL,
  `day` varchar(100) NOT NULL,
  `start_time` varchar(100) NOT NULL,
  `end_time` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 傾印資料表的資料 `courses`
--

INSERT INTO `courses` (`c_id`, `c_name`, `required`, `c_credit`, `department`, `c_grade`, `c_limit`, `current_enrollment`, `day`, `start_time`, `end_time`) VALUES
(10, '程式設計', '必修', 4, '資訊系', 1, 10, 5, '星期四', '08:10', '12:00'),
(11, '微積分1', '必修', 3, '資訊系', 1, 10, 10, '星期五', '13:10', '16:00'),
(12, '普通物理', '必修', 3, '資訊系', 1, 10, 5, '星期三', '14:10', '17:00'),
(13, '線性代數', '必修', 3, '資訊系', 1, 10, 4, '星期一', '09:10', '12:00'),
(14, '資料結構', '必修', 4, '資訊系', 2, 10, 7, '星期五', '08:10', '12:00'),
(15, '資料庫系統', '必修', 3, '資訊系', 2, 10, 7, '星期二', '09:10', '12:00'),
(16, '機率與統計', '必修', 3, '資訊系', 2, 10, 2, '星期一', '09:10', '12:00'),
(17, '密碼學', '選修', 3, '資訊系', 0, 10, 8, '星期三', '09:10', '12:00'),
(18, '電子商務安全', '選修', 4, '資訊系', 0, 10, 5, '星期二', '13:10', '17:00'),
(19, '互聯網路', '選修', 4, '資訊系', 0, 10, 4, '星期一', '13:10', '17:00'),
(21, '邏輯設計', '必修', 4, '電子系', 1, 10, 1, '星期三', '09:10', '12:00'),
(22, '計算機概論', '必修', 4, '電子系', 1, 10, 6, '星期四', '13:10', '17:00'),
(23, '普通物理', '必修', 4, '電子系', 1, 10, 3, '星期二', '13:10', '17:00'),
(24, '微積分', '必修', 3, '電子系', 1, 10, 5, '星期一', '13:10', '16:00'),
(25, '電路學', '必修', 3, '電子系', 2, 10, 6, '星期二', '14:10', '17:00'),
(26, '進階程式設計', '選修', 4, '電子系', 0, 10, 6, '星期三', '13:10', '17:00'),
(27, '電子材料', '選修', 4, '電子系', 0, 10, 3, '星期二', '08:10', '12:00'),
(28, '積體電路導論', '選修', 4, '電子系', 0, 10, 5, '星期一', '08:10', '12:00'),
(29, '介面設計', '選修', 4, '電子系', 0, 10, 6, '星期五', '13:10', '17:00'),
(31, '計算機概論', '必修', 4, '電通系', 1, 10, 6, '星期四', '13:10', '17:00'),
(32, '普通物理', '必修', 4, '電通系', 1, 10, 7, '星期四', '08:10', '12:00'),
(33, '工程數學', '必修', 3, '電通系', 2, 10, 6, '星期三', '13:10', '16:00'),
(34, '信號與系統', '必修', 3, '電通系', 2, 10, 4, '星期一', '09:10', '12:00'),
(35, '電路學', '必修', 3, '電通系', 2, 10, 3, '星期五', '09:10', '12:00'),
(36, '電子學', '必修', 4, '電通系', 2, 10, 6, '星期五', '13:10', '17:00'),
(37, '電磁學', '必修', 3, '電通系', 2, 10, 8, '星期二', '13:10', '17:00'),
(38, 'JAVA程式語言', '選修', 3, '電通系', 0, 10, 5, '星期一', '13:10', '16:00'),
(39, '物聯網應用實務', '選修', 3, '電通系', 0, 10, 6, '星期二', '09:10', '12:00'),
(132, '管理學', '必修', 3, '會計系', 2, 10, 8, '星期二', '14:10', '17:00'),
(1111, '微積分', '必修', 3, '資訊系', 1, 10, 6, '星期四', '13:10', '16:00'),
(1122, '普通物理', '必修', 3, '資訊系', 1, 10, 6, '星期五', '13:10', '16:00'),
(1433, '作業系統(一)', '必修', 3, '資訊系', 3, 10, 8, '星期四', '13:10', '16:00'),
(1436, '軟體測試', '選修', 3, '資訊系', 0, 10, 8, '星期三', '14:10', '17:00'),
(1437, '軟體工程與開發實務', '選修', 3, '資訊系', 0, 10, 8, '星期三', '13:10', '16:00'),
(1438, '軟體工程與開發實務', '選修', 3, '資訊系', 0, 10, 8, '星期二', '14:10', '17:00'),
(2277, '電子材料', '必修', 4, '電子系', 0, 10, 10, '星期四', '09:10', '12:00'),
(2288, '積體電路導論', '選修', 4, '電子系', 0, 10, 7, '星期四', '09:10', '12:00'),
(2299, '介面設計1', '選修', 4, '電子系', 0, 10, 4, '星期二', '13:10', '17:00'),
(3322, '普通物理', '必修', 4, '電通系', 1, 10, 10, '星期四', '08:10', '12:00'),
(3388, 'JAVA程式語言', '選修', 3, '電通系', 0, 10, 5, '星期二', '09:10', '12:00'),
(3399, '物聯網應用實務1', '選修', 3, '電通系', 0, 10, 5, '星期五', '13:10', '16:00');

-- --------------------------------------------------------

--
-- 資料表結構 `enrollments`
--

CREATE TABLE `enrollments` (
  `s_id` int(11) DEFAULT NULL,
  `c_id` int(11) DEFAULT NULL,
  `c_name` varchar(100) DEFAULT NULL,
  `required` varchar(100) DEFAULT NULL,
  `c_credit` int(11) DEFAULT NULL,
  `day` varchar(100) DEFAULT NULL,
  `start_time` varchar(100) NOT NULL,
  `end_time` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 傾印資料表的資料 `enrollments`
--

INSERT INTO `enrollments` (`s_id`, `c_id`, `c_name`, `required`, `c_credit`, `day`, `start_time`, `end_time`) VALUES
(11111, 14, '資料結構', '必修', 4, '星期五', '08:10', '12:00'),
(11111, 15, '資料庫系統', '必修', 3, '星期二', '09:10', '12:00'),
(11111, 16, '機率與統計', '必修', 3, '星期一', '09:10', '12:00'),
(22222, 21, '邏輯設計', '必修', 4, '星期三', '09:10', '12:00'),
(22222, 22, '計算機概論', '必修', 4, '星期四', '13:10', '17:00'),
(22222, 23, '普通物理', '必修', 4, '星期二', '13:10', '17:00'),
(22222, 24, '微積分', '必修', 3, '星期一', '13:10', '16:00'),
(33333, 33, '工程數學', '必修', 3, '星期三', '13:10', '16:00'),
(33333, 34, '信號與系統', '必修', 3, '星期一', '09:10', '12:00'),
(33333, 35, '電路學', '必修', 3, '星期五', '09:10', '12:00'),
(33333, 36, '電子學', '必修', 4, '星期五', '13:10', '17:00'),
(33333, 37, '電磁學', '必修', 3, '星期二', '13:10', '17:00'),
(11111, 19, '互聯網路', '選修', 4, '星期一', '13:10', '17:00'),
(11111, 19, '互聯網路', '選修', 4, '星期一', '13:10', '17:00');

-- --------------------------------------------------------

--
-- 資料表結構 `student`
--

CREATE TABLE `student` (
  `s_id` int(11) NOT NULL,
  `s_name` varchar(255) NOT NULL,
  `major` varchar(255) NOT NULL,
  `credits` int(11) NOT NULL,
  `s_grade` int(11) NOT NULL,
  `s_password` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 傾印資料表的資料 `student`
--

INSERT INTO `student` (`s_id`, `s_name`, `major`, `credits`, `s_grade`, `s_password`) VALUES
(11111, '學生A', '資訊系', 14, 2, 123),
(22222, '學生B', '電子系', 15, 1, 234),
(33333, '學生C', '電通系', 16, 2, 345),
(44444, '學生D', '資訊系', 0, 4, 456);

-- --------------------------------------------------------

--
-- 資料表結構 `teacher`
--

CREATE TABLE `teacher` (
  `t_id` int(11) NOT NULL,
  `t_name` varchar(255) NOT NULL,
  `t_password` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 傾印資料表的資料 `teacher`
--

INSERT INTO `teacher` (`t_id`, `t_name`, `t_password`) VALUES
(1256, '老師A', 1289),
(4112, '老師B', 5721),
(3245, '老師C', 54678);

--
-- 已傾印資料表的索引
--

--
-- 資料表索引 `classtime`
--
ALTER TABLE `classtime`
  ADD PRIMARY KEY (`start_time`,`end_time`);

--
-- 資料表索引 `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`c_id`,`c_name`,`required`,`c_credit`,`day`,`start_time`,`end_time`),
  ADD KEY `start_time` (`start_time`,`end_time`);

--
-- 資料表索引 `enrollments`
--
ALTER TABLE `enrollments`
  ADD KEY `s_id` (`s_id`),
  ADD KEY `c_id` (`c_id`,`c_name`,`required`,`c_credit`,`day`,`start_time`,`end_time`);

--
-- 資料表索引 `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`s_id`);

--
-- 已傾印資料表的限制式
--

--
-- 資料表的限制式 `courses`
--
ALTER TABLE `courses`
  ADD CONSTRAINT `courses_ibfk_1` FOREIGN KEY (`start_time`,`end_time`) REFERENCES `classtime` (`start_time`, `end_time`);

--
-- 資料表的限制式 `enrollments`
--
ALTER TABLE `enrollments`
  ADD CONSTRAINT `enrollments_ibfk_1` FOREIGN KEY (`s_id`) REFERENCES `student` (`s_id`),
  ADD CONSTRAINT `enrollments_ibfk_2` FOREIGN KEY (`c_id`,`c_name`,`required`,`c_credit`,`day`,`start_time`,`end_time`) REFERENCES `courses` (`c_id`, `c_name`, `required`, `c_credit`, `day`, `start_time`, `end_time`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
