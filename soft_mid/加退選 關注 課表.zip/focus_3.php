取消關注
<?php
    if(isset($_POST['drop_c_id'])) {
		session_start();
		
		$drop_c_id=$_POST["drop_c_id"];
    
		$_SESSION["drop_c_id"]= $drop_c_id;
		$student_id=$_SESSION["student_id"] ;
	
		$dbhost = '127.0.0.1';
		$dbuser = 'hj';
		$dbpass = 'test1234';
		$dbname = 'soft_mid';
		$conn = mysqli_connect($dbhost, $dbuser, $dbpass) or die('Error with MySQL connection');
		mysqli_query($conn, "SET NAMES 'utf8'");
		mysqli_select_db($conn, $dbname);

		$query="SELECT * FROM courses WHERE c_id = $drop_c_id";
		$result = mysqli_query($conn, $query) or die(mysqli_error($conn));
	
        $sql_1 = "DELETE FROM focus WHERE c_id = ".$drop_c_id." AND s_id LIKE \"".$student_id."%\";";
		mysqli_query($conn, $sql_1);
       
        

    }
        header('Location: action1.php?status=success');//關注成功
	    exit;
    
    

?>