判斷關注
<?php
    if(isset($_POST['drop_c_id'])) {
		session_start();
		
		$drop_c_id=$_POST["drop_c_id"];
    
		$_SESSION["drop_c_id"]= $drop_c_id;
		$student_id=$_SESSION["student_id"] ;
	
		$dbhost = '127.0.0.1';
		$dbuser = 'hj';
		$dbpass = 'test1234';
		$dbname = 'soft_mid';
		$conn = mysqli_connect($dbhost, $dbuser, $dbpass) or die('Error with MySQL connection');
		mysqli_query($conn, "SET NAMES 'utf8'");
		mysqli_select_db($conn, $dbname);

		$query="SELECT * FROM courses WHERE c_id = $drop_c_id";
		$result = mysqli_query($conn, $query) or die(mysqli_error($conn));


        $c_name='';
            $required='';
            $c_credit=0;
            $day='';
            $start_time='';
            $end_time='';

            if ($result) {
                while ($row = mysqli_fetch_array($result)) {
                    $c_name=$row['c_name'];
                    //echo $row['c_name'];
                    $required=$row['required'];
                    $c_credit=$row['c_credit'];

                    $department=$row['department'];
                    $c_grade=$row['c_grade'];
                    $c_limit=$row['c_limit'];
                    $current_enrollment=$row['current_enrollment'];
                    $day=$row['day'];
                    $start_time=$row['start_time'];
                    $end_time=$row['end_time'];
                }
            } else {
                echo "查詢失敗或沒有結果";
            }
		    
	
        
        $query="SELECT focus_id FROM focus";
		$result = mysqli_query($conn, $query) or die('MySQL query error');
        $id=0;
        while($row = mysqli_fetch_array($result)){
            if($id<$row['focus_id'])
            {
                $id=$row['focus_id'];
            }
            $id++;
        }
        if($id==0)
        {
            $id=1;
        }

            $sql_focus = "INSERT INTO focus (focus_id,s_id,c_id,c_name,required,c_credit,department,c_grade,c_limit,current_enrollment,day,start_time,end_time)
                                    VALUES({$id},{$student_id},{$drop_c_id},'{$c_name}','{$required}',{$c_credit},'{$department}',{$c_grade},{$c_limit},{$current_enrollment},'{$day}','{$start_time}','{$end_time}');";
            mysqli_query($conn, $sql_focus);
        //}
        

    }
        header('Location: focus.php?status=success');//關注成功
	    exit;
    
    

?>